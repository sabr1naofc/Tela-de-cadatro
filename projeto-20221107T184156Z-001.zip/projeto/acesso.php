<html><head>
    <title> Seu Cadastro </title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <a href="login.php"> <button class="btn btn-lg btn-info btn-block" type="submit"> Volte para seu login </button></a><br>
    </head>
<body> 
    <div class="card-header">
						<h1>Bem vindo ao seu Cadastro</h1> <br> <br>
					</div>
      <div class="card-body">
    </div>
    
          <center></center><table class="table" align="center" border="9">
   <thead>
   <tr>
       <th><h2> PAIS/CIDADE</h2></th>
       <th><h2>VALOR</h2></th>
        <th><h2>DATA P/ IR</h2></th>
         <th><h2> DATA P/ VOLTAR</h2></th>
       
   </tr>
   </thead>
   <tbody>
   <tr>
       <td><h3> JAMAICA</h3></td>
       <td><h3> R$ 4.000 REIAS </h3></td>
       <td><h3> 22/03/2021</h3></td>
       <td><h3> 01/04/2021</h3></td>
   </tr>
   <tr>
       <td><h3> RÚSSIA</h3></td>
       <td><h3> R$ 10.000 REIAS</h3></td>
       <td><h3>07/08/2022 </h3></td>
       <td><h3> 30/08/2022 </h3></td>
   </tr>
   </tbody>
   <tfoot>
       <tr><td><h3>INGLATERRA</h3></td>
       <td><h3> R$ 12.000 REAIS </h3></td>
       <td><h3>01/01/2023 </h3></td>
       <td><h3>01/03/2023</h3></td>
   </tr></tfoot>
<tbody><tr>
    <td><h3> LISBOA/POR </h3></td>
       <td><h3> R$ 11.000 REAIS</h3></td>
       <td><h3>05/06/2023</h3></td>
       <td><h3>11/07/2023</h3></td>
   </tr>
              <tr>
       <td><h3>PARIS/FRA</h3></td>
       <td><h3> R$ 17.000 REAIS</h3></td>
       <td><h3> 08/12/2021</h3></td>
       <td><h3> 05/01/2022</h3></td>
   </tr>
              <tr>
       <td><h3>BUENOS AIRES/ARG</h3></td>
       <td><h3>R$ 7.000 REAIS</h3></td>
       <td><h3>08/11/2022</h3></td>
       <td><h3>01/12/2022</h3></td>
   </tr>
              <tr>
       <td><h3> CANCÚN/MEX</h3></td>
       <td><h3> R$ 9.000 REIAS </h3></td>
       <td><h3>02/02/2024 </h3></td>
       <td><h3>02/03/2024</h3></td>
   </tr>
    
    </tbody></table>   

</body></html>