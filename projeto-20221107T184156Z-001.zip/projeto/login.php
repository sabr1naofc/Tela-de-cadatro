<html>
    <head>

        <title> Login </title>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="estilo.css">
    
    </head>
<body>
    
    <form name="loginform" method="post" action="acesso.php">
        <div class="card-header">
            <br><br>
						<h2> Entre no seu login</h2>
					</div>
    <center> <h3> E-mail: </h3> <input type="text" name="email" /><br> </center> <br/>
    <center> <h3> Senha: </h3> <input type="password" name="senha" /><br> </center> <br />
    <center> <input type="submit" value="Entre" /> </center>
    </form>
    
    </body>

</html>