<?php
//----------conectando no banco---------
$hostname = "localhost";
$user = "root";
$password = "";
$database = "cadastro";
$conexao = mysqli_connect($hostname,$user,$password,$database);

if(!$conexao){
    print "Falha na conexão com Banco de Dados";
}

include_once("conexao.php");

$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$pais = $_POST['pais'];
$estado = $_POST['estado'];
$cidade = $_POST['cidade'];
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "insert into usuarios(nome,sobrenome,pais,estado,cidade,email,password) values ('$nome','$sobrenome','$pais','$estado','$cidade','$email','$password')";
$salvar = mysqli_query($conexao,$sql);


mysqli_close($conexao);

?>

<hmtl>

<head>
    
    <title> LOGAR </title>
    <a href="login.php"> <button class="btn btn-lg btn-info btn-block" type="submit"> Clique aqui para entrar no seu Cadastro </button></a><br>
   </head>
    <body>
    <h3> Cadastro efetuado com sucesso! </h3>
    
   </body>

</hmtl>