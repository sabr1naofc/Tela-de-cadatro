<html>
<head>
    <title> Sistema de Cadastro </title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <a href="login.php"> <button class="btn btn-lg btn-info btn-block" type="submit"> Faça Seu Login </button></a><br>
    
    </head>
    
<body>
    <h2> Cadastro de Usuário </h2>
    <div class="card-header">
						<h1>Acesso</h1>
					</div>
    
    <div class="card-body">
						<form method="post" action="conexao.php">
<div class="form-group">
								<input type="text" name="nome" class="form-control" placeholder="Nome">
							</div>
							<div class="form-group">
								<input type="text" name="sobrenome" class="form-control" placeholder="Sobrenome">
							</div>
                            <div class="form-group">
								<input type="text" name="pais" class="form-control" placeholder="Pais">
							</div>
                            <div class="form-group">
								<input type="text" name="estado" class="form-control" placeholder="Estado">
							</div>
                            <div class="form-group">
								<input type="text" name="cidade" class="form-control" placeholder="Cidade">
							</div>
                            <div class="form-group">
								<input type="email" name="email" class="form-control" placeholder="Email">
							</div>
                            <div class="form-group">
								<input type="password" name="password" class="form-control" placeholder="Senha">
							</div>
                            
							<button class="btn btn-lg btn-info btn-block" type="submit"> Cadastrar</button>
                         
						</form>
    </div>
   
    
    </body>

</html>